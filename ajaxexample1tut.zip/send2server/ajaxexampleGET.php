Hi this is a very simple AJAX example.

<?php
//echo "<br>";
echo date('l jS \of F Y h:i:s A');
?>